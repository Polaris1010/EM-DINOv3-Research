HQ-5nm, 25 fields at 5 nm/pixel, four model/window combinations.
Original 2048 x 2048 grid. PNG white = predicted mitochondria, black = background.
Frozen 130k encoder + matched CEM-MitoLab Primus 40k, seed 20261014.
Window stride is half its width. Ground truth is unavailable.
